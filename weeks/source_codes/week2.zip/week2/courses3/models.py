from flask_sqlalchemy import SQLAlchemy

from cache import cache

db = SQLAlchemy()


class Course(db.Model):

    __tablename__ = "courses"
    id = db.Column(db.Integer(), primary_key=True, unique=True)
    course_name = db.Column(db.Text())
    department = db.Column(db.Text())
    instructor_fullname = db.Column(db.Text())
    course_id = db.Column(db.Integer())


    @classmethod
    @cache.memoize(timeout=10)
    def get_course(cls, id):
        print("Not Memoised Course Response!")
        result = db.session.query(cls).get(id)
        return {
            "id": result.id,
            "course_name": result.course_name,
            "departrment": result.department,
            "instructor": result.instructor_fullname,
            "course_id": result.course_id
        }


class Enrollment(db.Model):
    
    __tablename__ = "enrollments"
    id = db.Column(db.Integer(), primary_key=True, unique=True)
    course_id = db.Column(db.Integer(), db.ForeignKey('courses.id'))
    total = db.Column(db.Integer())
    course = db.relationship('Course')


    @classmethod
    @cache.memoize(timeout=10)
    def get_enrollments(cls):
        print("Not Memoised Enrollment Response!")
        return [{"course_id":enrollment.course.course_id, 
             "enrollment": enrollment.total} 
             for enrollment in cls.query.all()]
    
    
