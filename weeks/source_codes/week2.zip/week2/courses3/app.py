from flask import Flask, render_template, request


from models import *
from cache import cache
from task import import_file


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///./course3.db'
app.config["CACHE_TYPE"] = "RedisCache"
app.config["CACHE_REDIS_URL"] = "redis://localhost:6379/1"
app.config["CACHE_DEFAULT_TIMEOUT"] = 300



db.init_app(app)
cache.init_app(app)


@app.route('/')
@cache.cached(timeout=10)
def index():
    print("Not Cached Reponse!")
    return render_template("index.html")


@app.route("/courses")
def get_courses():
    return [{"name": x.course_name, 
             "department": x.department, 
             "instructor": x.instructor_fullname,
             "course_id": x.course_id} for x in Course.query.all()]


@app.route('/realtime')
def realtime():
    return [{"course_id":enrollment.course.course_id, 
             "enrollment": enrollment.total} 
             for enrollment in Enrollment.query.all()]


@app.route("/details/<int:id>")
def get_details(id):
    return Course.get_course(id) 

if __name__ == "__main__":
    app.run(debug=True)
