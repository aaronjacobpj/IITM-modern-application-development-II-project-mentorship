const app = Vue.createApp({
    template: `
        <div class="container-fluid">
            <div id="chart">
            </div>
        </div>
        <div class="container-fluid">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">course Id</th>
                        <th scope="col">Course</th>
                        <th scope="col">Department</th>
                        <th scope="col">Instructor</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="course in courses">
                        <th scope="row">{{ course["course_id"] }}</th>
                        <td>{{ course["name"] }}</td>
                        <td>{{ course["department"] }}</td>
                        <td>{{ course["instructor"] }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    `,
    data(){
        return {
            message: "Hello World!",
            courses: [],
            file: null,
            chart: [],
        }
    },
    created(){
        this.getdata();
       
        setInterval(()=>{
            this.get_chart()
        }, 30000*2);
    },
    mounted(){
        this.get_chart();
       
    },
    methods:{
        get_chart(){

            response = fetch('/realtime').then(x => x.json());
            response.then(x =>{ this.chart = x; this.draw()})
        },
        getdata(){
            response = fetch('/courses').then(x => x.json());
            response.then(x => this.courses = x);
        },
        draw(){

            var options = {
                series: [{
                name: "Enrollments",
                data: this.chart.map(x => x["enrollment"])
            }],
                chart: {
                height: 350,
                type: 'line',
                zoom: {
                enabled: false
                }
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                curve: 'straight'
            },
            title: {
                text: 'Course Tredline',
                align: 'left'
            },
            grid: {
                row: {
                colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
                opacity: 0.5
                },
            },
            xaxis: {
                categories: this.chart.map(x => x["course_id"]),
            }
            };
    
            var chart = new ApexCharts(document.querySelector("#chart"), options);
            chart.render();
        }
    }
})

app.mount("#app")