from app import db, app, Course

def main():
    with open("collection/courses.csv") as file:
        header = file.readline().strip().split(",")
        rows = []

        for row in  file.readlines():
            rows.append({
                header[index]: value 
                for value, index in zip(row.split(","), range(len(header)))
            })

    with app.app_context():
        db.create_all()
        for row in rows:
            course = Course(course_name=row["course_name"],
                            department=row["department"],
                            course_id=row["course_id"],
                            instructor_fullname=row["instructor_fullname"]
                            )
            
            db.session.add(course)
            db.session.commit()


if __name__ == "__main__":
    main()
