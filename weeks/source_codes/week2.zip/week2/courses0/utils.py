from app import db, Course


def import_file(file):
    header = file.readline().decode().strip().split(",")
    rows = []

    for row in  file.readlines():
        row = row.decode()
        rows.append({
            header[index]: value 
            for value, index in zip(row.split(","), range(len(header)))
        })


    db.create_all()
    for row in rows:
        course = Course(course_name=row["course_name"],
                        department=row["department"],
                        course_id=row["course_id"],
                        instructor_fullname=row["instructor_fullname"]
                        )
        
        db.session.add(course)
        db.session.commit()
