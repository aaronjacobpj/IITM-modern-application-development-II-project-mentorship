from flask import Flask, render_template, request

from models import *
from utils import import_file


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///./course.db'


db.init_app(app)

@app.route('/')
def index():
    return render_template("index.html")


@app.route("/courses")
def get_courses():
    return [{"name": x.course_name, 
             "department": x.department, 
             "instructor": x.instructor_fullname,
             "course_id": x.course_id} for x in Course.query.all()]


@app.route("/upload", methods=["GET", "POST"])
def upload():
    file = request.files.get("data")

    import_file(file.stream)
    
    return "Done!"


if __name__ == "__main__":
    app.run(debug=True)
