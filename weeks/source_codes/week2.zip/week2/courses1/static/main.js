const app = Vue.createApp({
    template: `
        <div class="container-fluid">
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">File</label>
                <input type="file" class="form-control" id="exampleFormControlInput1" @change="open" placeholder="Select a file">
                <input @click="upload" type="button" value="Import" class="btn btn-primary" style="margin-top:2%"/>
            </div>
        </div>
        <div class="container-fluid">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">course Id</th>
                        <th scope="col">Course</th>
                        <th scope="col">Department</th>
                        <th scope="col">Instructor</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="course in courses">
                        <th scope="row">{{ course["course_id"] }}</th>
                        <td>{{ course["name"] }}</td>
                        <td>{{ course["department"] }}</td>
                        <td>{{ course["instructor"] }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    `,
    data(){
        return {
            message: "Hello World!",
            courses: [],
            file: null
        }
    },
    created(){
        this.getdata();
    },
    methods:{
        getdata(){
            response = fetch('/courses').then(x => x.json());
            response.then(x => this.courses = x);
        },
        upload(){
            if(this.file)
                data = new FormData()
                data.append('data', this.file)
                response = fetch('/upload', {method:"POST", body: data})
                response.then(x =>{
                    if (x.status == 200){
                        this.getdata();
                    }
                })
        },
        open(event){
            this.file = event.target.files[0]
        }
    }
})

app.mount("#app")