from flask import Flask, send_file, send_from_directory
from io import BytesIO
from jinja2 import Template



app = Flask(__name__)

@app.route('/')
def index():
    return send_file("image.jpg", as_attachment=True)


@app.route('/pdf')
def pdf():
    return send_file("image.pdf")

@app.route('/csv')
def csv():

    return send_file("courses.csv")

@app.route("/generate")
def generate():

    file = open("hello.html")
    template = Template(file.read())
    file.close()
    
    content = template.render(name="Charlie")
    
    file_io = BytesIO()
    file_io.write(bytes(content, "utf-8"))
    file_io.seek(0)

    return send_file(
        file_io,
        as_attachment=True,
        download_name='hello.html',
    )

