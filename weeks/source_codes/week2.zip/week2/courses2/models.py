from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Course(db.Model):

    __tablename__ = "courses"
    id = db.Column(db.Integer(), primary_key=True, unique=True)
    course_name = db.Column(db.Text())
    department = db.Column(db.Text())
    instructor_fullname = db.Column(db.Text())
    course_id = db.Column(db.Integer())


class Enrollment(db.Model):
    
    __tablename__ = "enrollments"
    id = db.Column(db.Integer(), primary_key=True, unique=True)
    course_id = db.Column(db.Integer(), db.ForeignKey('courses.id'))
    total = db.Column(db.Integer())
    course = db.relationship('Course')
