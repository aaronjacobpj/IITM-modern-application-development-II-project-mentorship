from flask import Flask, render_template, request

from models import *
from task import import_file


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///./course2.db'


db.init_app(app)

@app.route('/')
def index():
    return render_template("index.html")


@app.route("/courses")
def get_courses():
    return [{"name": x.course_name, 
             "department": x.department, 
             "instructor": x.instructor_fullname,
             "course_id": x.course_id} for x in Course.query.all()]


@app.route('/realtime')
def realtime():
    return [{"course_id":enrollment.course.course_id,
             "enrollment": enrollment.total} 
             for enrollment in Enrollment.query.all()]

if __name__ == "__main__":
    app.run(debug=True)
