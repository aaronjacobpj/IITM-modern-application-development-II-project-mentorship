const app = Vue.createApp({
    template: `
        <div class="container-fluid">
           <table class="table">
                <thead>
                    <tr>
                        <th scope="col">course Id</th>
                        <th scope="col">Enrollment</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="course in chart">
                        <th scope="row">{{ course["course_id"] }}</th>
                        <td>{{ course["enrollment"] }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="container-fluid">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">course Id</th>
                        <th scope="col">Course</th>
                        <th scope="col">Department</th>
                        <th scope="col">Instructor</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="course in courses">
                        <th scope="row">{{ course["course_id"] }}</th>
                        <td>{{ course["name"] }}</td>
                        <td>{{ course["department"] }}</td>
                        <td>{{ course["instructor"] }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    `,
    data(){
        return {
            message: "Hello World!",
            courses: [],
            file: null,
            chart: [],
        }
    },
    created(){
        this.getdata();
       
        setInterval(()=>{
            this.get_chart()
        }, 30000*2);
    },
    mounted(){
        this.get_chart();
       
    },
    methods:{
        get_chart(){

            response = fetch('/realtime').then(x => x.json());
            response.then(x =>{ this.chart = x; this.draw()})
        },
        getdata(){
            response = fetch('/courses').then(x => x.json());
            response.then(x => this.courses = x);
        }
    }
})

app.mount("#app")