import random

from app import Enrollment, db
from app import app as flask_app

from celery import Celery
from celery.schedules import crontab


celery = Celery("worker", 
                backend='redis://localhost', 
                broker="redis://localhost:6379/1",
                broker_connection_retry_on_startup=True
                )


@celery.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):

    sender.add_periodic_task(
        crontab(minute="*"),
        enrolled.s(),
    )



@celery.task
def enrolled():
    
    with flask_app.app_context():
        
        for enrollment in Enrollment.query.all():
            enrollment.total = random.randint(0, 100)

        db.session.commit()


