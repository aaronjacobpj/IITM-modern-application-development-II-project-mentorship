//  Vue component
export const home = {
    template: `<h1> Hello World</h1>`
}