export const greet = {
    template: '<h1>Hello, {{ $route.params.user }}</h1>'
}