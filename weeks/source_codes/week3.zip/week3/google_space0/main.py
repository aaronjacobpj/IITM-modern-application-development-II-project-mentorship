from json import dumps
import requests
import os


WEBHOOK_URL = os.environ.get("WEBHOOK")

def main():
    """Google Chat incoming webhook quickstart."""
    app_message = {
        'text': 'Hello World!'}
    message_headers = {'Content-Type': 'application/json; charset=UTF-8'}
    requests.post(
        url=WEBHOOK_URL,
        headers=message_headers,
        data=dumps(app_message),
    )


if __name__ == '__main__':
    main()