from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import smtplib


sender = "abcd@example.com"
password = "password"
receiver = "abd@example.com"

msg = MIMEMultipart()

f = open("text.txt")
content = f.read()
f.close()

file = MIMEText(content)
file.add_header("content-disposition", f"attachment; filename=text.txt")
msg.attach(file)


f = open("image.png", "rb")
content = f.read()
f.close()

file = MIMEBase("application", "octet-stream")
file.set_payload(content)
file.add_header("content-disposition", "attachment; filename=image.png")
encoders.encode_base64(file) # Convert binary object base64 string

msg.attach(file)

# to send
mail = smtplib.SMTP("localhost", 1025)
mail.login(sender, password)

mail.sendmail(sender, receiver, msg.as_string())
mail.close()

