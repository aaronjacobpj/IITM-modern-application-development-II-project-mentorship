import AdminView from "./AdminView.js"
import HomeView from "./HomeView.js"
import ErrorView from "./error/error.js";

const routes = [{path: "/admin/:role", name: "admin", component: AdminView, props:true},
    {path: "/", name: "home", component: HomeView},
    {path: "/error/:error", name: "error", component: ErrorView, props:true}

]

const router = VueRouter.createRouter({
    // 4. Provide the history implementation to use. We are using the hash history for simplicity here.
    history: VueRouter.createWebHashHistory(),
    routes, // short for `routes: routes`
  })

router.beforeEach(async (to, from) => {
    console.log(from)
    if (to.fullPath.match(/^[/]admin/) && to.params.role == "admin"){

    }
    else if (to.name == "admin"){
        return {name: "error", params: {error: "Un authorised"}}
    }

  })


export default router;

"/admin/profile"
"admin/setting"