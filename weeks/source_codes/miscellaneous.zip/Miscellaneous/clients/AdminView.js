import router from "./router.js"

const AdminView = {
    template: `
        <h1> Admin Page </h1>
    `,
    props: ["role"],
    beforeCreate(){
        if(this.role != "admin"){
            // router.push({name: "error", params: {error: "Un authorised!"}});
        }
    }
}

export default AdminView;