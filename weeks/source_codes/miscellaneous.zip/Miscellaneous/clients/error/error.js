import router from "../router.js"

const ErrorView = {
    template: `
        <h1> {{ error }} </h1>
    `,
    props: ["error"],
    created(){
        
    }
}

export default ErrorView;