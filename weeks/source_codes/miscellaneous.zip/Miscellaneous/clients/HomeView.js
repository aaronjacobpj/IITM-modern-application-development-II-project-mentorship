import router from "./router.js"

const HomeView = {
    template: 
    `<input type="text" v-model="role"/>
    <input type="buttton" @click="login" value="Login"/>`
    ,
    data(){
        return{
            role: null
        }
    },
    methods:{
        login(){
            router.push({name: "admin", params: {role: this.role}});
        }
    }
}

export default HomeView;