import router from "./router.js"
import AdminView from "./AdminView.js"
import HomeView from "./HomeView.js"

const app = Vue.createApp({
    template:  `
        <router-view/>
    `,
    data(){
        return{
            username: null
        }
    },
    methods:{
        login(){
            
        }
    }
})

app.use(router);
app.component("AdminView", AdminView)
app.component("HomeView", HomeView)

app.mount("#app")