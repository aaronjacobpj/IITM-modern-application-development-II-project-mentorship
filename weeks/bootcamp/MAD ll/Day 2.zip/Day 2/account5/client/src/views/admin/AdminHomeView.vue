<script setup>
    import Navbar from "@/components/admin/Navbar.vue";
    import { RouterView } from "vue-router";
</script>
<template>
    <Navbar/>
    <RouterView/>
</template>