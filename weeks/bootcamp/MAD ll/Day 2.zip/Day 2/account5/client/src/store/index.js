import { createStore } from "vuex";

export default createStore({
    state()
    {
        var roles = []
        var token = null
        if(sessionStorage.getItem("roles")){
            roles = sessionStorage.getItem("roles")
            token = sessionStorage.getItem("token")
        }
        return{
            roles: roles,
            token: token
        }
    },
    getters:{
        getRoles(state){
            console.log(state.roles);
            return state.roles;
        }
    },
    mutations:{
        setRoles(state, value){
            sessionStorage.setItem("roles", value)
            state.roles = value;
        },
        setToken(state, value){
            sessionStorage.setItem("token", value)
            state.token = value
        },
        clearSession(state){
            state.roles = []
            state.token = null
            sessionStorage.removeItem("token")
            sessionStorage.removeItem("roles")
        }
    }
})