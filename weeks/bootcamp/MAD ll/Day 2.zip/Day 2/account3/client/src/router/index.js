import { createRouter, createWebHistory } from 'vue-router'

import MainHomeView from "@/views/MainHomeView.vue";
import SigninView from "@/views/SigninView.vue";
import RegisterView from "@/views/RegisterView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'main-home-view',
      component: MainHomeView,
      children:[
        {
          path: 'register',
          name: 'register',
          component: RegisterView
        },
        {
          path: 'signin',
          name: 'signin',
          component: SigninView
        },
      ]
    },
    
  ]
})

export default router
