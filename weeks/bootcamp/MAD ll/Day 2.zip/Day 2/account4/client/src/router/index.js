import { createRouter, createWebHistory } from 'vue-router'

import store from '@/store'; 

import MainHomeView from "@/views/MainHomeView.vue";
import SigninView from "@/views/SigninView.vue";
import RegisterView from "@/views/RegisterView.vue";

import UserHomeView from "@/views/user/UserHomeView.vue";
import UserDashboardView from "@/views/user/UserDashboardView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'main-home-view',
      component: MainHomeView,
      children:[
        {
          path: 'register',
          name: 'register',
          component: RegisterView
        },
        {
          path: 'signin',
          name: 'signin',
          component: SigninView
        },
      ]
    },
    {
      path: "/user",
      name: "user-home-view",
      component: UserHomeView,
      children: [
        {
          path: 'dashboard',
          name: 'user-dashboard',
          component: UserDashboardView
        },
      ]
    }
    
  ]
})

router.beforeEach((to, from)=>{
  if(to.path.startsWith("/user")){
    if(store.getters.getRoles.includes("user"))
    {
      return true
    }
    else
    {
      return {name: "signin"}
    }
  }
})

export default router
