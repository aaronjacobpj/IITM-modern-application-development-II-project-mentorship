<script setup>
    import store from "@/store"
</script>
<template>
    <h1>User Home Page</h1>
    <h2> Your token is: {{ store.state.token }} </h2>
</template>