from flask import Blueprint, request
from flask import current_app as app
from flask_security import login_user, auth_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash


from .models import db, UserRoles


api = Blueprint("api", __name__, url_prefix="/api")


@api.route("/register", methods=["POST"])
def register():
    if request.method == "POST":
        email = request.json.get("email")
        fullname = request.json.get("fullname")
        password = request.json.get("password")

        response = {}
        if not email:
            response["email"] = False
        else:
            response["email"] = True
        
        if not fullname:
            response["fullname"] = False
        else:
            response["fullname"] = True

        if not password:
            response["password"] = False
        else:
            response["password"] = True

        if not response["email"] or not response["fullname"] or not response["password"]:
            return response, 400
        
        if app.security.datastore.find_user(email=email):
            response["exist"] = True
            return response, 409
    
        app.security.datastore.create_user(fullname=fullname,
                                           email=email, 
                                           password=generate_password_hash(password),
                                           balance=0)
        db.session.flush()

        user = app.security.datastore.find_user(email=email)
        role = app.security.datastore.find_role(role="user")

        user_role = UserRoles(user_id=user.id, role_id=role.id)
        db.session.add(user_role)
        db.session.commit()

        return {"message": "Request successful"}, 201




@api.route("/signin", methods=["POST"])
def signin():
    if request.method == "POST":

        email = request.json.get("email")
        password = request.json.get("password")

        user = app.security.datastore.find_user(email=email)

        if not user or not check_password_hash(user.password, password):
            return {"message": "User not found!"}, 404
        else:
            login_user(user)
            roles = []
            for role in current_user.roles:
                roles.append(role.name)

            return {"roles": roles, "token": current_user.get_auth_token()}
        

