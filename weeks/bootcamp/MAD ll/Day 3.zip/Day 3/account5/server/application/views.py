from flask import Blueprint, request
from flask import current_app as app
from flask_security import login_user, auth_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

import datetime

from .models import db, UserRoles, Transaction


api = Blueprint("api", __name__, url_prefix="/api")


@api.route("/register", methods=["POST"])
def register():
    if request.method == "POST":
        email = request.json.get("email")
        fullname = request.json.get("fullname")
        password = request.json.get("password")

        response = {}
        if not email:
            response["email"] = False
        else:
            response["email"] = True
        
        if not fullname:
            response["fullname"] = False
        else:
            response["fullname"] = True

        if not password:
            response["password"] = False
        else:
            response["password"] = True

        if not response["email"] or not response["fullname"] or not response["password"]:
            return response, 400
        
        if app.security.datastore.find_user(email=email):
            response["exist"] = True
            return response, 409
    
        app.security.datastore.create_user(fullname=fullname,
                                           email=email, 
                                           password=generate_password_hash(password),
                                           balance=0)
        db.session.flush()

        user = app.security.datastore.find_user(email=email)
        role = app.security.datastore.find_role(role="user")

        user_role = UserRoles(user_id=user.id, role_id=role.id)
        db.session.add(user_role)
        db.session.commit()

        return {"message": "Request successful"}, 201




@api.route("/signin", methods=["POST"])
def signin():
    if request.method == "POST":

        email = request.json.get("email")
        password = request.json.get("password")

        user = app.security.datastore.find_user(email=email)

        if not user or not check_password_hash(user.password, password):
            return {"message": "User not found!"}, 404
        else:
            login_user(user)
            roles = []
            for role in current_user.roles:
                roles.append(role.name)

            return {"roles": roles, "token": current_user.get_auth_token()}
        

@api.route("/user/profile")
@auth_required("token")
def user_profile():
    return {
        "fullname": current_user.fullname,
        "email": current_user.email,
        "balance": current_user.balance
    }

@api.route("/user/add-money", methods=["POST"])
@auth_required("token")
def user_add_money():
    if request.method == "POST":
        amount = request.json.get("amount", int)
        
        if isinstance(amount, int):

            current_user.balance += amount
            db.session.commit()
            return {"message": "Rquest successful"}
        
        return {"message": "Invalid amount"}, 400
    

@api.route("/user/withdraw-money", methods=["POST"])
@auth_required("token")
def user_withdraw_money():
    if request.method == "POST":
        amount = request.json.get("amount", int)
        
        # check if the user input is avlid
        if not isinstance(amount, int) or amount > current_user.balance:
            return {"message": "Invalid amount"}, 400
        
        today = datetime.date.today()
        month = datetime.date(year=today.year,
                              month=today.month,
                              day=1)

        # Check if number of withdrawal transaction done by the use in the current month
        # is less than five else return error otherwise deduct and update trasaction
        if Transaction.query.filter(Transaction.date >= month)\
            .filter_by(type="WITHDRAW", user_id=current_user.id).count() >= 5:
            return {"message": "Reached maximum time you can withdraw per month"}, 406

        current_user.balance -= amount
        transaction = Transaction(user_id=current_user.id,
                                    type="WITHDRAW",
                                    amount=amount,
                                    date=today)
        db.session.add(transaction)
        db.session.commit()
        return {"message": "Rquest successful"}
        
