import { createRouter, createWebHistory } from 'vue-router'

import store from '@/store'; 

import MainHomeView from "@/views/MainHomeView.vue";
import SigninView from "@/views/SigninView.vue";
import RegisterView from "@/views/RegisterView.vue";

import UserHomeView from "@/views/user/UserHomeView.vue";
import UserDashboardView from "@/views/user/UserDashboardView.vue";

import AdminHomeView from "@/views/admin/AdminHomeView.vue";
import AdminDashboardView from "@/views/admin/AdminDashboardView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'main-home-view',
      component: MainHomeView,
      children:[
        {
          path: 'register',
          name: 'register',
          component: RegisterView
        },
        {
          path: 'signin',
          name: 'signin',
          component: SigninView
        },
      ]
    },
    {
      path: "/user",
      name: "user-home-view",
      component: UserHomeView,
      children: [
        {
          path: 'dashboard',
          name: 'user-dashboard',
          component: UserDashboardView
        },
      ]
    },
    {
      path: "/admin",
      name: "admin-home-view",
      component: AdminHomeView,
      children: [
        {
          path: 'dashboard',
          name: 'admin-dashboard',
          component: AdminDashboardView
        },
      ]
    },
  ]
})

router.beforeEach((to, from)=>{
  if(to.path.startsWith("/user")){
    if(store.getters.getRoles.includes("user"))
    {
      return true
    }
    else
    {
      return {name: "signin"}
    }
  }
  else if(to.path.startsWith("/admin")){
    if(store.getters.getRoles.includes("admin"))
    {
      return true
    }
    else
    {
      return {name: "signin"}
    }
  }
  else if(to.path == "/signout")
  {
    store.commit("clearSession");
    return {name: 'signin'}
  }
})

export default router
