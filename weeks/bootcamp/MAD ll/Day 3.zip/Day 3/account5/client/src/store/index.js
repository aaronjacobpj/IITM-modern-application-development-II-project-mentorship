import { createStore } from "vuex";

export default createStore({
    state()
    {
        var roles = []
        var token = null
        if(sessionStorage.getItem("roles")){
            roles = sessionStorage.getItem("roles")
            token = sessionStorage.getItem("token")
        }
        return{
            URL: "http://127.0.0.1:5000/api/",
            roles: roles,
            token: token,
            profile: {}
        }
    },
    getters:{
        getRoles(state){
            return state.roles;
        },
        getProfile(state){
            return state.profile
        },
        getToken(state){
            return state.token;
        }
    },
    mutations:{
        setRoles(state, value){
            sessionStorage.setItem("roles", value)
            state.roles = value;
        },
        setToken(state, value){
            sessionStorage.setItem("token", value)
            state.token = value
        },
        clearSession(state){
            state.roles = []
            state.token = null
            sessionStorage.removeItem("token")
            sessionStorage.removeItem("roles")
        },
        setProfile(state, value){
            console.log(value)
            state.profile = value
        }
    },
    actions:{
        setProfile({commit, state}){
            fetch(state.URL+"user/profile",{
                headers:{
                    "Authentication-Token": state.token
                }
            }).then(response=>{
                if(response.status == 200)
                {
                    return response.json()
                }
                else
                {
                    return {}
                }
            }).then(value=>{
                commit("setProfile", value);
            })
        }
    }
})