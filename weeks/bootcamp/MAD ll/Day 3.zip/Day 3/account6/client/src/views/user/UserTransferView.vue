<script setup>
    import store from "@/store"
</script>