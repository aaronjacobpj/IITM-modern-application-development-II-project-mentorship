<template>
    <h1>Create an account</h1>
</template>