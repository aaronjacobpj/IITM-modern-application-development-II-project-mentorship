import { createRouter, createWebHistory } from 'vue-router'

import SigninView from "@/views/SigninView.vue";
import RegisterView from "@/views/RegisterView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/register',
      name: 'register',
      component: RegisterView
    },
    {
      path: '/signin',
      name: 'signin',
      component: SigninView
    },
    
  ]
})

export default router
