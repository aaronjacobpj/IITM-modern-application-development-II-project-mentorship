<script setup>
    import Navbar from "@/components/Navbar.vue";
</script>
<template>
    <Navbar/>
    <h1>Signin Page</h1>
</template>