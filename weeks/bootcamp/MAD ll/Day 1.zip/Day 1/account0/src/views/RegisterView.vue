<script setup>
    import Navbar from "@/components/Navbar.vue";
</script>
<template>
    <Navbar/>
    <h1>Create an account</h1>
</template>