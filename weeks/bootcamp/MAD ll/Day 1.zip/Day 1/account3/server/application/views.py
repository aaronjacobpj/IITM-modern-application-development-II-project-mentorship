from flask import Blueprint, request


api = Blueprint("api", __name__, url_prefix="/api")


@api.route("/register", methods=["GET", "POST"])
def register():
    return request.json