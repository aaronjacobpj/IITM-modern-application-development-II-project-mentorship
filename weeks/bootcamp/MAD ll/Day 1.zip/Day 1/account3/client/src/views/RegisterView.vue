<template>
    <div class="container-fluid" id="form-container">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title" align="center">Register</h3>
                <form>
                    <div class="row">
                        <div class="col">
                            <label for="fullname-input" class="form-label">Full Name</label>
                            <input type="text" class="form-control" placeholder="Full Name" 
                                id="fullname-input" aria-label="Full Name" v-model="fullname"
                                @focusout="validate_fullname">
                            <div class="valid-feedback" v-if="fullname != null" :style="{display: valid['fullname']}">
                                Looks good!
                            </div>
                            <div class="invalid-feedback" :style="{display: error['fullname']}">
                                Please type your full name.
                            </div>
                        </div>
                        <div class="col">
                            <label for="email-input" class="form-label">Email</label>
                            <input type="email" class="form-control" placeholder="Email" id="email-input" aria-label="Email">

                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label for="password-input" class="form-label">Password</label>
                            <input type="password" class="form-control" placeholder="Password" id="password-input" aria-label="Password">

                        </div>
                        <div class="col">
                            <label for="re-password-input" class="form-label">Password</label>
                            <input type="password" class="form-control" placeholder="Password" id="re-password-input" aria-label="Password">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col" style="padding: 10px;display: flex;justify-content: center;">
                            <input type="submit" class="btn btn-primary" value="Signin" aria-label="Signin">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    export default
    {
        data(){
            return{
                email: null,
                password: null,
                repassword: null,
                fullname: null,
                error: {
                    email: "none",
                    fullname: "none",
                },
                valid: {
                    email: "none",
                    fullname: "none",
                }
            }
        },
        methods: {
            validate_fullname()
            {                    
                this.valid["fullname"] = "none"
                this.error["fullname"] = "none"

                if(this.fullname != null && this.fullname.length > 2){
                    this.valid["fullname"] = "block"
                }
                else{
                    this.error["fullname"] = "block"
                }
            }
        }
    }
</script>
<style scoped>
    #form-container{
        width: 100%;
        height: 90vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .row{
        padding: 8px;
    }
</style>