<template>
    <div class="container-fluid" id="form-container">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title" align="center">Sign in</h3>
                <form @submit="register">
                    <div class="row">
                        <div class="col">
                            <label for="email-input" class="form-label">Email</label>
                            <input type="email" class="form-control" placeholder="email" 
                                id="email-input" aria-label="Email" v-model="email">
                            <div class="invalid-feedback" :style="{display:error['email']}">
                                Please enter a valid mail.
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label for="password-input" class="form-label">Password</label>
                            <input type="password" class="form-control" placeholder="Password" 
                                id="password-input" aria-label="Password" v-model="password">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col" style="padding: 10px;display: flex;justify-content: center;">
                            <input type="submit" class="btn btn-primary" value="Signin" 
                                aria-label="Signin" >
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    export default 
    {
        data()
        {
            return {
                email: "",
                password: null,
                error:{
                    email: "none",
                    password: "none"
                }
                
            }
        },
        methods:{
            validate()
            {
                this.error = {
                    email: "none",
                    password: "none"
                }
                if(!this.email.match(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/))
                {
                    this.error["email"] = "block"
                    return false
                }

                return true
            },
            register(event)
            {
                event.preventDefault();
                if(this.validate()){
                    fetch("http://127.0.0.1:5000/api/register",
                    {
                        method: "POST",
                        headers: 
                        {
                            "Content-Type": "application/json",
                        },
                        body: JSON.stringify({
                            email: this.email,
                            password: this.password 
                        })
                    }).then(response=>{
                        if(response.status == 200){
                            alert("Request Successfull")
                        }
                    })
                }
            }
        }
    }
</script>
<style scoped>
    #form-container{
        width: 100%;
        height: 90vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>