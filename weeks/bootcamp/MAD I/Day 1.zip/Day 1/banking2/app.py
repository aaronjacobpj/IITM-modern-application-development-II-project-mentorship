from flask import Flask, render_template, request, session, redirect


app = Flask(__name__)

app.config["SECRET_KEY"] = "asdfghjrtyuixcvbn"


@app.route("/signin", methods=["GET", "POST"])
def signin():
    if request.method == "GET":
        return render_template("signin.html")
    
    elif request.method == "POST":
        session["user"] = request.form
        return request.form


@app.route("/register")
def register():
    if "user" in session:
        return session["user"]
    else:
        return redirect("/signin")
