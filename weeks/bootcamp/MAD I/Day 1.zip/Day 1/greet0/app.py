from flask import Flask

app = Flask(__name__)


@app.route("/")
def index():
    return "<h1>Hello, World!</h1>"


@app.route("/greet/Charlie")
def greet_charlie():
    return "<h1>Hello, Charlie!</h1>"

@app.route("/greet/Bob")
def greet_bob():
    return "<h1>Hello, Bob!</h1>"