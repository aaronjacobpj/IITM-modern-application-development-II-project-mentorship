from flask import Flask, render_template, request

app = Flask(__name__)

users = "Hello, World!"

@app.route("/signin", methods=["GET", "POST"])
def signin():
    if request.method == "GET":
        return render_template("signin.html")
    
    elif request.method == "POST":
        global users
        users = request.form
        return users


@app.route("/register")
def register():
    return users

