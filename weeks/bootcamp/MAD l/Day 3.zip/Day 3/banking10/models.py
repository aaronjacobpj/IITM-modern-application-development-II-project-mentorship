from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()


class User(db.Model):

    __tablename__ = "user"
    id = db.Column(db.Integer(), primary_key=True)
    firstname = db.Column(db.String(), nullable=False)
    lastname = db.Column(db.String())
    email = db.Column(db.String(), nullable=False, unique=True)
    password = db.Column(db.String(), nullable=False)
    balance = db.Column(db.Integer(), nullable=False)
    role = db.Column(db.String(), nullable=False)


class DepositType(db.Model):

    __tablename__ = "deposit_type"
    id = db.Column(db.Integer(), primary_key=True)
    deposit = db.Column(db.String(), nullable=False, unique=True)
    interest_rate = db.Column(db.Float(), nullable=False)
    Days = db.Column(db.Integer(), nullable=False)


class Deposit(db.Model):

    __tablename__ = "deposit"
    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), foreign_key=db.ForeignKey("user.id"), nullable=False)
    deposit = db.Column(db.Integer(), foreign_key=db.ForeignKey("deposit_type.id"), nullable=False)
    amount = db.Column(db.Integer(), nullable=False)
    

class Transaction(db.Model):
    
    __tablename__ = "transactions"
    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), foreign_key=db.ForeignKey("user.id"), nullable=False)
    receiver_id =  db.Column(db.Integer(), foreign_key=db.ForeignKey("user.id"))
    type = db.Column(db.String(), nullable=False)
    amount = db.Column(db.Integer(), nullable=False)
    date = db.Column(db.Date(), nullable=False)

