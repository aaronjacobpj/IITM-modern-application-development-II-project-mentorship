from flask import Blueprint, request, render_template, session, redirect
from werkzeug.security import generate_password_hash, check_password_hash

import datetime

from models import db, User, Transaction
from helpers import login_required


api = Blueprint("api", __name__, url_prefix="")


@api.route("/user/")
@login_required
def user_index():

    user = User.query.filter_by(id=session.get("user-id")).first()

    today = datetime.datetime.today()
    month = datetime.date(year=today.year, 
                            month=today.month,
                            day=1)

    if Transaction.query.filter(Transaction.date >= month).filter_by(user_id=user.id, type="WITHDRAW").count() >= 5:
        return render_template("user/index.html", user=user, withdraw_limit=True)
    
    return render_template("user/index.html", user=user)


@api.route("/admin/")
@login_required
def admin_index():

    user = User.query.filter_by(id=session.get("user-id")).first()

    today = datetime.datetime.today()
    month = datetime.date(year=today.year, 
                            month=today.month,
                            day=1)
    
    # get all the users from the database
    account_holders = User.query.filter_by(role="user").all()


    for each in account_holders:

        # check if each user balance is betweeen 500 and 100
        if each.balance <= 500 and each.balance > 100:

            # if not the penalty is already deducted, deduct the penalty and
            # add the transaction to to database
            if not Transaction.query.filter(Transaction.date > month)\
                .filter_by(type="BALANCE-PENALTY", user_id=each.id).first():
                each.balance -= 100
                transaction = Transaction(user_id=each.id,
                                    type="BALANCE-PENALTY",
                                    amount=100,
                                    date=today)
                db.session.add(transaction)
                db.session.commit()

    return render_template("admin/index.html", user=user)



@api.route("/signin", methods=["GET", "POST"])
def signin():
    if request.method == "GET":
        return render_template("signin.html")
    
    elif request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        user = User.query.filter_by(email=email).first()

        if not user or not check_password_hash(user.password, password):
            return render_template("signin.html", 
                                   error=True,
                                   email=email)

        session["user-id"] = user.id
        session["user-role"] = user.role

        if user.role == "admin":
            return redirect("/admin/")
        else:
            return redirect("/user/")


@api.route("/signout")
def signout():
    session.clear()
    return redirect("/signin")


@api.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    
    elif request.method == "POST":
        firstname = request.form.get("firstname")
        lastname = request.form.get("lastname")
        email = request.form.get("email")
        password = request.form.get("password")
        repassword = request.form.get("repassword")

        firstname_error = False
        email_error = False
        password_error = None

        if firstname == "":
            firstname_error = True
        
        if email == "":
            email_error = True
        
        if password != repassword:
            password_error = "Password doesn't match"

        if password == "":
            password_error = "Password required!"
        
        if firstname_error or password_error or email_error:

            return render_template("register.html",
                                firstname=firstname,
                                lastname=lastname,
                                email=email,
                                password=password,
                                repassword=repassword, 
                                firstname_error=firstname_error,
                                email_error=email_error,
                                password_error=password_error)
    
        else:
            if lastname == "":
                lastname = None
            user = User(firstname=firstname,
                        lastname=lastname,
                        email=email,
                        password=generate_password_hash(password),
                        balance=1000,
                        role="user")
            db.session.add(user)
            db.session.commit()

            return redirect("/signin")
            
        
@api.route("/user/add-money", methods=["POST"])
@login_required
def user_add_money():
    if request.method == "POST":
        
        # parse the amount as an integer
        amount = request.form.get("amount", type=int)
        user = User.query.filter_by(id=session["user-id"]).first()

        # Check if amount is invalid and return an error
        if not amount:
            return render_template("user/index.html", user=user, amount=True)
        
        # Update balance and return dashboard
        user.balance += amount
        db.session.commit()
        return redirect("/user")    
    

@api.route("/user/withdraw-money", methods=["POST"])
@login_required
def user_withdraw_money():
    
    if request.method == "POST":

        # parse the amount as an integer
        amount = request.form.get("amount", type=int)
        user = User.query.filter_by(id=session["user-id"]).first()

        today = datetime.datetime.today()
        month = datetime.date(year=today.year, 
                              month=today.month,
                              day=1)
        
        # Check if amount is invalid and return an error
        if not amount or amount > user.balance:
            return render_template("user/index.html", user=user, withdraw=True)
        
        elif Transaction.query.filter(Transaction.date >= month).filter_by(user_id=user.id, type="WITHDRAW").count() >= 5:
            return redirect("/user")
        
        # if valid amount and satisfy monthly constraint deduct and render dashboard
        # and create an transaction
        user.balance -= amount

        transaction = Transaction(user_id=user.id,
                                  type="WITHDRAW",
                                  amount=amount,
                                  date=today)
        db.session.add(transaction)
        db.session.commit()

        return redirect("/user") 
    

@api.route("/user/statement", methods=["GET", "POST"])
@login_required
def user_statement():
    user = User.query.filter_by(id=session["user-id"]).first()

    # if get method retreive transaction done by the user and render it
    if request.method == "GET":
        transactions = Transaction.query.filter_by(user_id=user.id).all()
        return render_template("user/statement.html", transactions=transactions)
    
    # if post request get the filter from form and render the transaction
    # according to the filter
    elif request.method == "POST":
        start_date = request.form.get("start-date")
        end_date = request.form.get("end-date")


        # check if date is empty if empty render error
        if not start_date or not end_date:
            transactions = Transaction.query.filter_by(user_id=user.id).all()
            return render_template("user/statement.html", 
                                   transactions=transactions,
                                   invalid_form=True)

        # try to parse the date if it's valid else render error
        try:
            start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d")
            end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d")
        except:
            transactions = Transaction.query.filter_by(user_id=user.id).all()
            return render_template("user/statement.html", 
                                   transactions=transactions,
                                   invalid_form=True)
        

        # Check if start date is greater than the end date if it is render error message
        # else filter the statement from the transaction table using start and end date
        # and render it
        if  start_date > end_date:
            transactions = Transaction.query.filter_by(user_id=user.id).all()
            return render_template("user/statement.html", 
                                   transactions=transactions,
                                   invalid_form=True)

        else:
            transactions = Transaction.query.filter(Transaction.date >= start_date,
                                                    Transaction.date <= end_date)\
                            .filter_by(user_id=user.id).all()
            
            return render_template("user/statement.html", 
                                    transactions=transactions)


