from flask import Flask


def create_app():

    from models import db

    app = Flask(__name__)

    app.config["SECRET_KEY"] = "asdfghjrtyuixcvbn"
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"

    db.init_app(app)

    with app.app_context():
        db.create_all()

    from views import api

    app.register_blueprint(api)

    return app

app = create_app()
