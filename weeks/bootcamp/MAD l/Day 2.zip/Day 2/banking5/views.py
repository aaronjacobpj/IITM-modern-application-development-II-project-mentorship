from flask import Blueprint, request, render_template, session, redirect
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User

api = Blueprint("api", __name__, url_prefix="")


@api.route("/signin", methods=["GET", "POST"])
def signin():
    if request.method == "GET":
        return render_template("signin.html")
    
    elif request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        user = User.query.filter_by(email=email).first()

        if user is None or not check_password_hash(user.password, password):
            return render_template("signin.html", 
                                   error=True,
                                   email=email)

        return request.form


@api.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    
    elif request.method == "POST":
        firstname = request.form.get("firstname")
        lastname = request.form.get("lastname")
        email = request.form.get("email")
        password = request.form.get("password")
        repassword = request.form.get("repassword")

        firstname_error = False
        email_error = False
        password_error = None

        if firstname == "":
            firstname_error = True
        
        if email == "":
            email_error = True
        
        if password != repassword:
            password_error = "Password doesn't match"

        if password == "":
            password_error = "Password required!"
        
        if firstname_error or password_error or email_error:

            return render_template("register.html",
                                firstname=firstname,
                                lastname=lastname,
                                email=email,
                                password=password,
                                repassword=repassword, 
                                firstname_error=firstname_error,
                                email_error=email_error,
                                password_error=password_error)
    
        else:
            if lastname == "":
                lastname = None
            user = User(firstname=firstname,
                        lastname=lastname,
                        email=email,
                        password=generate_password_hash(password),
                        balance=0,
                        role="user")
            db.session.add(user)
            db.session.commit()

            return redirect("/signin")
            
        
    
    