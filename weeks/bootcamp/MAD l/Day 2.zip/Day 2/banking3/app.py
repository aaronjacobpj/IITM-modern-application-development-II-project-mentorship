from flask import Flask, render_template, request, session, redirect


app = Flask(__name__)

app.config["SECRET_KEY"] = "asdfghjrtyuixcvbn"


@app.route("/signin", methods=["GET", "POST"])
def signin():
    if request.method == "GET":
        return render_template("signin.html")
    
    elif request.method == "POST":
        session["user"] = request.form
        return request.form


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    
    elif request.method == "POST":
        firstname = request.form.get("firstname")
        lastname = request.form.get("lastname")
        email = request.form.get("email")
        password = request.form.get("password")
        repassword = request.form.get("repassword")

        firstname_error = False
        email_error = False
        password_error = None

        if firstname == "":
            firstname_error = True
        
        if email == "":
            email_error = True
        
        if password != repassword:
            password_error = "Password doesn't match"

        if password == "":
            password_error = "Password required!"
        
        if firstname_error or password_error or email_error:

            return render_template("register.html",
                                firstname=firstname,
                                lastname=lastname,
                                email=email,
                                password=password,
                                repassword=repassword, 
                                firstname_error=firstname_error,
                                email_error=email_error,
                                password_error=password_error)
    
        else:
            return request.form
        
    
    