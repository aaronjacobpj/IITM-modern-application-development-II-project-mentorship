import csv

from app import create_app
from models import db, User
from werkzeug.security import generate_password_hash



def main():

    #  intialise the app
    app = create_app()


    # create table if empty
    with app.app_context():
        db.create_all()
    

    emails = set()

    # iterate through the rows and add users to the db
    with app.app_context():
        for row in read_csv("data/users.csv"):

            # check if user email exist in email then skip insert
            # otherwise add the entry
            if row["email"] in emails:
                continue
            
            user = User(firstname=row["first_name"],
                        lastname=row["last_name"],
                        email=row["email"],
                        password=generate_password_hash(row["username"]),
                        balance=1000,
                        role="user"
                        )
            db.session.add(user)
            emails.add(row["email"])

        db.session.commit()


def read_csv(filename):
    # read the file as a csv
    with open(filename) as file:

        # convert the row to dict
        reader = csv.DictReader(file)

        rows = []
        # add each row to the list
        for row in reader:
            rows.append(row)

    return rows



if __name__ == "__main__":
    main()