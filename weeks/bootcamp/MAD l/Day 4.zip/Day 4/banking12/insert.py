import csv
import random
import datetime

from app import create_app
from models import db, User, Transaction
from werkzeug.security import generate_password_hash


MAXROWS = 100

def main():

    #  intialise the app
    app = create_app()


    # create table if empty
    with app.app_context():
        db.create_all()
    

    emails = set()

    # iterate through the rows and add users to the db
    with app.app_context():
        for row in read_csv("data/users.csv"):

            # check if user email exist in email then skip insert
            # otherwise add the entry
            if row["email"] in emails:
                continue
            
            user = User(firstname=row["firstname"],
                        lastname=row["lastname"],
                        email=row["email"],
                        password=generate_password_hash(row["firstname"]),
                        balance=1000,
                        role="user"
                        )
            db.session.add(user)
            emails.add(row["email"])

        db.session.commit()

    with app.app_context():
        add_money(db)


def read_csv(filename):
    # read the file as a csv
    with open(filename) as file:

        # convert the row to dict
        reader = csv.DictReader(file)

        rows = []
        # add each row to the list
        for row in reader:
            rows.append(row)

    return rows


def add_money(db):
    # set a seed
    random.seed(100)

    # dates for random selection
    dates = [datetime.date(2023, 10, 12), datetime.date(2023, 10, 16),
             datetime.date(2023, 10, 24), datetime.date(2023, 11, 12),
             datetime.date(2023, 11, 27), datetime.date(2024, 1, 12),
             datetime.date(2024, 2, 12), datetime.date(2023, 3, 1)
    ]

    # select all users
    users = User.query.filter_by(role="user").all()

    # select MAXROWS number of dates in chronological order
    transaction_dates = random.choices(dates, k=MAXROWS)
    transaction_dates = sorted(transaction_dates)

    # randomly add the transaction to the db
    for i in range(MAXROWS):
        user = random.choice(users)
        amount = random.randint(100, 10000)
        entry = Transaction(user_id=user.id,
                            amount=amount,
                            type="DEPOSIT",
                            date=transaction_dates[i])
        db.session.add(entry)

    db.session.commit()


if __name__ == "__main__":
    main()